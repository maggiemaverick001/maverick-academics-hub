MAVERICK ACADEMICS HUB — Website files

QUICK START
1. Open index.html in a web browser to preview the website on your computer.
2. To publish it online, upload index.html to a static website host such as GitHub Pages, Netlify, or Cloudflare Pages.
3. The site is responsive and includes learning notes, a working multiple-choice quiz, and a contact form that prepares an email draft.

IMPORTANT
- The contact form currently uses the visitor's email app (mailto). It does not store or send messages to a database.
- The website is a static front-end. No account, database, or hosting has been configured.
